<?php

use App\Http\Controllers\AnimalController;
use App\Http\Controllers\AnimalPrintController;
use App\Http\Controllers\BirthController;
use App\Http\Controllers\BreedingController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\DeploymentController;
use App\Http\Controllers\ExitController;
use App\Http\Controllers\InventoryController;
use App\Http\Controllers\InventoryPurchaseController;
use App\Http\Controllers\InventoryUsageController;
use App\Http\Controllers\MasterDataController;
use App\Http\Controllers\OperatorController;
use App\Http\Controllers\OperatorInventoryController;
use App\Http\Controllers\ScanController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\Admin\PartnerController;
use App\Http\Controllers\Admin\ReportController;
use App\Http\Controllers\CatalogueController;
use App\Http\Controllers\InvoiceController;
use App\Http\Controllers\PartnerDashboardController;
use App\Http\Controllers\SiteContentController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

// --- GUEST INFORMATIONAL PAGES ---
Route::prefix('layanan')->name('pages.')->group(function () {
    Route::view('digitalisasi-ternak', 'pages.digital-livestock')->name('digital-livestock');
    Route::view('monitoring-kesehatan', 'pages.health-monitoring')->name('health-monitoring');
    Route::view('manajemen-pakan', 'pages.feed-management')->name('feed-management');
    Route::view('sales-tracking', 'pages.sales-tracking')->name('sales-tracking');
});

Route::name('pages.')->group(function () {
    Route::view('tentang-kami', 'pages.about-us')->name('about-us');
    Route::view('syarat-ketentuan', 'pages.terms')->name('terms');
    Route::view('kebijakan-privasi', 'pages.privacy')->name('privacy');
    Route::get('hubungi-kami', function () {
        $number = \App\Models\FarmSetting::get('whatsapp_number', '');
        return $number ? redirect("https://wa.me/{$number}") : redirect('/');
    })->name('contact');
    Route::get('katalog', [CatalogueController::class, 'index'])->name('catalogue');
    Route::get('artikel', [\App\Http\Controllers\PublicArticleController::class, 'index'])->name('articles.index');
    Route::get('artikel/{slug}', [\App\Http\Controllers\PublicArticleController::class, 'show'])->name('articles.show');
});

Route::middleware(['auth'])->group(function () {

    // --- NOTIFICATIONS ---
    Route::get('notifications', [\App\Http\Controllers\NotificationController::class , 'index'])->name('notifications.index');
    Route::get('notifications/{id}/read', [\App\Http\Controllers\NotificationController::class , 'read'])->name('notifications.read');
    // --- GROUP 1: OWNER ONLY (Admin & Settings) ---
    Route::middleware(['role:PEMILIK'])->group(function () {
            // Deployment Utilities
            Route::get('deploy/storage-link', [DeploymentController::class , 'linkStorage']);

            // Master Data
            Route::get('masters', [MasterDataController::class , 'index'])->name('masters.index');
            Route::post('masters/breed', [MasterDataController::class , 'storeBreed'])->name('masters.breed.store');
            Route::post('masters/location', [MasterDataController::class , 'storeLocation'])->name('masters.location.store');
            Route::post('masters/disease', [MasterDataController::class , 'storeDisease'])->name('masters.disease.store');
            Route::post('masters/item', [MasterDataController::class , 'storeItem'])->name('masters.item.store');
            Route::post('masters/category', [MasterDataController::class , 'storeCategory'])->name('masters.category.store');

            // Master Data Edit Routes
            Route::get('masters/breed/{breed}/edit', [MasterDataController::class , 'editBreed'])->name('masters.breed.edit');
            Route::put('masters/breed/{breed}', [MasterDataController::class , 'updateBreed'])->name('masters.breed.update');

            Route::get('masters/location/{location}/edit', [MasterDataController::class , 'editLocation'])->name('masters.location.edit');
            Route::put('masters/location/{location}', [MasterDataController::class , 'updateLocation'])->name('masters.location.update');

            Route::get('masters/category/{category}/edit', [MasterDataController::class , 'editCategory'])->name('masters.category.edit');
            Route::put('masters/category/{category}', [MasterDataController::class , 'updateCategory'])->name('masters.category.update');

            Route::get('masters/disease/{disease}/edit', [MasterDataController::class , 'editDisease'])->name('masters.disease.edit');
            Route::put('masters/disease/{disease}', [MasterDataController::class , 'updateDisease'])->name('masters.disease.update');

            // SOP Tasks
            Route::post('masters/sops', [MasterDataController::class , 'storeSop'])->name('masters.sop.store');
            Route::put('masters/sops/{sop}', [MasterDataController::class , 'updateSop'])->name('masters.sop.update');
            Route::delete('masters/sops/{sop}', [MasterDataController::class , 'destroySop'])->name('masters.sop.destroy');

            // Farm Settings
            Route::post('masters/settings', [MasterDataController::class , 'updateSettings'])->name('masters.settings.update');

            // Site Content CMS
            Route::get('admin/site-content', [SiteContentController::class, 'index'])->name('admin.site-content.index');
            Route::post('admin/site-content', [SiteContentController::class, 'update'])->name('admin.site-content.update');

            // Articles CRUD
            Route::resource('admin/articles', \App\Http\Controllers\Admin\ArticleController::class)->names('admin.articles');
            Route::post('admin/articles/upload-media', [\App\Http\Controllers\Admin\ArticleController::class, 'uploadMedia'])->name('admin.articles.upload-media');

            // Export & Backup
            Route::prefix('admin/export')->name('admin.export.')->group(function () {
                Route::get('/animals', [\App\Http\Controllers\ExportController::class, 'animals'])->name('animals');
                Route::get('/animals/template', [\App\Http\Controllers\ExportController::class, 'template'])->name('animals.template');
                Route::get('/full-backup', [\App\Http\Controllers\ExportController::class, 'fullBackup'])->name('full-backup');
                Route::post('/reconcile', [\App\Http\Controllers\ExportController::class, 'reconcile'])->name('reconcile');
                Route::get('/reconciliation', [\App\Http\Controllers\ExportController::class, 'index'])->name('reconciliation.index');
                Route::get('/reconciliation/{batch}', [\App\Http\Controllers\ExportController::class, 'show'])->name('reconciliation.show');
            });

            // Report Exports (multi-format)
            Route::prefix('admin/reports/export')->name('admin.reports.export.')->group(function () {
                Route::get('/{reportType}/{format}', [\App\Http\Controllers\ReportExportController::class, 'export'])->name('download');
            });

            // User Management (Full Resource)
            Route::resource('users', UserController::class);

            // Partner Management
            // Partner Management
            Route::resource('partners', PartnerController::class);

        // Reports (Moved to Shared)
        }
        );

        // --- GROUP 2: MANAGERIAL (Owner & Breeder) ---
        Route::middleware(['role:PEMILIK,PETERNAK'])->group(function () {
            Route::get('/dashboard', [DashboardController::class , 'index'])->name('dashboard');

            // Animal Management (Write Access)
            Route::get('animals/template', [AnimalController::class , 'downloadTemplate'])->name('animals.template');
            Route::post('animals/import', [AnimalController::class , 'import'])->name('animals.import');
            Route::resource('animals', AnimalController::class)->except(['index', 'show']);
            Route::get('animals/{animal}/print', [AnimalPrintController::class , 'show'])->name('animals.print');

            // Breeding Flow
            Route::get('animals/{animal}/breeding/create', [BreedingController::class , 'create'])->name('breeding.create');
            Route::post('animals/{animal}/breeding', [BreedingController::class , 'store'])->name('breeding.store');

            // Mating Colonies
            Route::resource('mating-colonies', \App\Http\Controllers\MatingColonyController::class);

            // Birth Registry
            Route::get('birth/create', [BirthController::class , 'create'])->name('birth.create');
            Route::post('birth/store', [BirthController::class , 'store'])->name('birth.store');

            // Exit Flow
            Route::get('animals/{animal}/exit', [ExitController::class , 'create'])->name('animals.exit.create');
            Route::post('animals/{animal}/exit', [ExitController::class , 'store'])->name('animals.exit.store');

            // Inventory Management
            Route::resource('inventory', InventoryController::class)->except(['destroy']);
            Route::post('inventory/purchase', [InventoryPurchaseController::class , 'store'])->name('inventory.purchase.store');

            // Financial & Invoicing
            Route::resource('invoices', InvoiceController::class);
            Route::post('invoices/{invoice}/convert', [InvoiceController::class , 'convert'])->name('invoices.convert');
            Route::post('invoices/{invoice}/paid', [InvoiceController::class , 'markAsPaid'])->name('invoices.paid');

            // Manual HPP Inputs
            Route::resource('hpp-manual-costs', \App\Http\Controllers\HppManualCostController::class)->only(['index', 'store', 'destroy']);

            // Dashboard Settings
            Route::get('settings/dashboard', [\App\Http\Controllers\DashboardSettingController::class, 'index'])->name('settings.dashboard');
            Route::post('settings/dashboard', [\App\Http\Controllers\DashboardSettingController::class, 'store'])->name('settings.dashboard.store');
        }
        );

        // --- SHARED READ-ONLY (Owner, Breeder, Partner) ---
        Route::middleware(['role:PEMILIK,PETERNAK,MITRA'])->group(function () {
            Route::get('animals', [AnimalController::class , 'index'])->name('animals.index');
            Route::get('animals/{animal}', [AnimalController::class , 'show'])->where('animal', '[0-9a-fA-F\-]+')->name('animals.show');
            Route::get('reports', [ReportController::class , 'index'])->name('reports.index'); // Birth & Death
            Route::get('reports/sales', [ReportController::class , 'sales'])->name('reports.sales');
            Route::get('reports/stock', [ReportController::class , 'stock'])->name('reports.stock');
            Route::get('reports/stock/export', [ReportController::class , 'exportStock'])->name('reports.stock.export');
            Route::get('reports/partners', [ReportController::class , 'partners'])->name('reports.partners');
            Route::get('reports/operational', [ReportController::class , 'operational'])->name('reports.operational');
            Route::get('reports/performance', [ReportController::class , 'performance'])->name('reports.performance');
            Route::get('reports/reproduction', [ReportController::class , 'reproduction'])->name('reports.reproduction');
            Route::get('reports/audit', [ReportController::class , 'audit'])->name('reports.audit');
            Route::get('reports/mating', [ReportController::class , 'mating'])->name('reports.mating');
            Route::get('reports/nursing', [ReportController::class , 'nursing'])->name('reports.nursing');
            // Mating Colonies
            Route::resource('mating-colonies', \App\Http\Controllers\MatingColonyController::class);
        }
        );

        // --- GROUP 3: OPERATIONAL (Staff & Owner & Breeder) ---
        Route::middleware(['role:PEMILIK,STAF,PETERNAK'])->group(function () {
            Route::get('scan', [ScanController::class , 'index'])->name('scan.index');

            // Operator Workflow
            Route::get('operator/inventory', [OperatorInventoryController::class , 'index'])->name('operator.inventory.index');
            Route::post('inventory/usage', [InventoryUsageController::class , 'store'])->name('inventory.usage.store');

            Route::get('operator/{animal}', [OperatorController::class , 'show'])->name('operator.show');
            Route::post('operator/{animal}/weight', [OperatorController::class , 'storeWeight'])->name('operator.weight.store');
            Route::post('operator/{animal}/health', [OperatorController::class , 'storeHealth'])->name('operator.health.store');
            Route::post('operator/{animal}/move', [OperatorController::class , 'moveCage'])->name('operator.cage.move');
        }
        );

        // --- GROUP 4: PARTNER DASHBOARD ---
        Route::middleware(['role:MITRA'])->group(function () {
            Route::get('/partner/dashboard', [PartnerDashboardController::class , 'index'])->name('partner.dashboard');
        }
        );

        // --- ANIMAL TASKS ---
        Route::put('/tasks/{task}/mark-completed', [\App\Http\Controllers\AnimalTaskController::class, 'markCompleted'])->name('tasks.complete');

        // --- ANIMAL PHOTOS ---
        Route::delete('/animals/{animal}/photos/{photo}', [\App\Http\Controllers\AnimalController::class, 'deletePhoto'])->name('animals.photos.destroy');
    });

require __DIR__ . '/auth.php';
